package com.caltech.dbUtil;

public class DbUtilHelperConstant {
	public static final String DRIVER_CLASS="com.mysql.cj.jdbc.Driver";
	public static final String DB_URL="jdbc:mysql://localhost:3306/db5";
	public static final String USERNAME="root";
	public static final String PASSWORD="root";

}
