package com.caltech.pojo;

public class Participants {
	private int pid;
	private String password;
	private String pname;
	private String pemail;
	public Participants(int pid, String password) {
		super();
		this.pid = pid;
		this.password = password;
	}
	public Participants(int pid, String password, String pname, String pemail) {
		super();
		this.pid = pid;
		this.password = password;
		this.pname = pname;
		this.pemail = pemail;
	}
	public Participants() {
		// TODO Auto-generated constructor stub
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPemail() {
		return pemail;
	}
	public void setPemail(String pemail) {
		this.pemail = pemail;
	}
	
	

}
