package com.caltech.pojo;

public class Mapping {
	private int bid;
	private int pid;
	
	
	public Mapping() {
		
	}

	public Mapping(int bid, int pid) {
		super();
		this.bid = bid;
		this.pid = pid;
	}
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	

}
