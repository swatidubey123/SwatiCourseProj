package com.caltech.pojo;

public class Batch {
	private int bid;
	private String bname;
	private String instructor;
	private String bdate;
	private String btime;
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getInstructor() {
		return instructor;
	}
	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}
	public String getBdate() {
		return bdate;
	}
	public void setBdate(String bdate) {
		this.bdate = bdate;
	}
	public String getBtime() {
		return btime;
	}
	public void setBtime(String btime) {
		this.btime = btime;
	}
	public Batch(int bid, String bname, String instructor, String bdate, String btime) {
		super();
		this.bid = bid;
		this.bname = bname;
		this.instructor = instructor;
		this.bdate = bdate;
		this.btime = btime;
	}
	public Batch() {
		// TODO Auto-generated constructor stub
	}
	

}
