package com.caltech.pojo;

public class Admin {
	private String adminname;
	private String adminpassword;
	private String userRole;
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getAdminname() {
		return adminname;
	}
	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}
	public String getAdminpassword() {
		return adminpassword;
	}
	public void setAdminpassword(String adminpassword) {
		this.adminpassword = adminpassword;
	}
	public Admin(String adminname, String adminpassword,String userRole) {
		super();
		this.adminname = adminname;
		this.adminpassword = adminpassword;
		this.userRole = userRole;
	}
	

}
