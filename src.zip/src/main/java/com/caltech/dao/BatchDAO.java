package com.caltech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.caltech.dbUtil.DbUtil;
import com.caltech.pojo.Batch;

public class BatchDAO {
	//insert
	public int insert(Batch batch) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.getDbConn();
		String sql="insert into batch values(?,?,?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,batch.getBid());
		ps.setString(2,batch.getBname());
		ps.setString(3,batch.getInstructor());
		ps.setString(4,batch.getBdate());
		ps.setString(5,batch.getBtime());
		return ps.executeUpdate();
		
	}
	
	//retrive
public List<Batch> displayBatch() throws ClassNotFoundException, SQLException{
	Connection con=DbUtil.getDbConn();
	String sql="select * from batch";
	PreparedStatement ps=con.prepareStatement(sql);
	List<Batch> list=new ArrayList<>();
	ResultSet rs=ps.executeQuery();
	while(rs.next()) {
		Batch batch=new Batch();
		batch.setBid(rs.getInt("bid"));
		batch.setBname(rs.getString("bname"));
		batch.setInstructor(rs.getString("instructor"));
		batch.setBdate(rs.getString("bdate"));
		batch.setBtime(rs.getString("btime"));
		list.add(batch);
	}
	return list;
	
}
	//select by id
public Batch selectById(int id) throws ClassNotFoundException, SQLException {
	Connection con=DbUtil.getDbConn();
	System.out.println("bid inside selectById"+id);
	String sql="select * from batch where bid=?";
	PreparedStatement ps=con.prepareStatement(sql);
	
	ps.setInt(1, id);
	ResultSet rs=ps.executeQuery();
if(rs.next()) {
	System.out.println("rs is not empty");
}
		int bid=rs.getInt("bid");
		String bname=rs.getString("bname");
		String instructor=rs.getString("instructor");
		String bdate=rs.getString("bdate");
		String btime=rs.getString("btime");
		Batch batch=new Batch(bid, bname, instructor, bdate,btime);
		
		return batch;
	
	
}
//update 
public int edit(Batch batch) throws ClassNotFoundException, SQLException {
	Connection con=DbUtil.getDbConn();
	//System.out.println("pid inside edit method in product dao"+product.getPid());
	String sql="update batch set bname=?,instructor=?,bdate=?,btime=? where bid=?";
	PreparedStatement ps=con.prepareStatement(sql);
	ps.setString(1,batch.getBname());
	ps.setString(2, batch.getInstructor());
	ps.setString(3, batch.getBdate());
	ps.setString(4, batch.getBtime());
	ps.setInt(5, batch.getBid());
	return ps.executeUpdate();
}
	
//delete

public int delete(int bid) throws ClassNotFoundException, SQLException {
	Connection con=DbUtil.getDbConn();
	System.out.println("pid inside delete method in product dao"+bid);
	String sql="delete from map_batch_part  where bid=?";
	PreparedStatement ps=con.prepareStatement(sql);		
	ps.setInt(1, bid);
	 ps.executeUpdate();
	 String sql1="delete from batch where bid=?";
	 PreparedStatement ps1=con.prepareStatement(sql1);		
		ps1.setInt(1, bid);
		return ps1.executeUpdate();
}



}
