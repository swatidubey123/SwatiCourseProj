package com.caltech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.caltech.dbUtil.DbUtil;
import com.caltech.pojo.Mapping;


public class MapRegisterBatchDAO {
	public int insert(Mapping map) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.getDbConn();
		String sql="insert into map_batch_part values(?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,map.getBid());
		ps.setInt(2,map.getPid());
		
		return ps.executeUpdate();
		
	}
}
