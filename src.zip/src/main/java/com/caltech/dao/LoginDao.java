package com.caltech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.caltech.dbUtil.DbUtil;
import com.caltech.pojo.Admin;


public class LoginDao {
	public String validate(Admin admin) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.getDbConn();
		String sql="select * from Admin";
		PreparedStatement ps=con.prepareStatement(sql);				
		ResultSet rs=ps.executeQuery();
		String adminname=admin.getAdminname();
		String adminpassword=admin.getAdminpassword();
		String userRole=admin.getUserRole();
		//System.out.println("adminname in logindao"+adminname);
		
		while(rs.next()) {
			if(adminname.equals(rs.getString("adminname"))) {
				if(adminpassword.equals(rs.getString("adminpassword"))){	
					if(rs.getString("userRole").equalsIgnoreCase("admin"))	{
					System.out.println("user role is admin");
					break;
					}
				}
			}
			else if(adminname.equals(rs.getString("adminname"))) {
				if(adminpassword.equals(rs.getString("adminpassword"))){	
					if(rs.getString("userRole").equalsIgnoreCase("User"))	{
						System.out.println("the role is user");
					
					break;
					}
				}
			}
			else {
				System.out.println("please register yourself");
				break;
			}
			
		}
		
		return userRole;
	}

}
