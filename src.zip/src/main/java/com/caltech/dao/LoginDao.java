package com.caltech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.caltech.dbUtil.DbUtil;
import com.caltech.pojo.Admin;
import com.caltech.pojo.Participants;


public class LoginDao {
	public String validate(Admin admin) throws ClassNotFoundException, SQLException {
		Connection con=DbUtil.getDbConn();
		String sql="select * from Admin where adminname=? AND adminpassword=? AND userrole='admin'";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, admin.getAdminname());
		ps.setString(2,admin.getAdminpassword());
		ResultSet rs=ps.executeQuery();
		
		//System.out.println("pid inside user login method"+participant.getPid());
		//Participants resParticipant= new Participants();
		
		if(rs.next()) {
			
				
					return rs.getString("adminname");
					
				
			}
			
			else {
				System.out.println("not a registered admin");
				return "doReg";
			}
			
		
	}


}
