package com.caltech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.caltech.dbUtil.DbUtil;
import com.caltech.pojo.Admin;
import com.caltech.pojo.Participants;

public class ParticipantDAO {
	//insert
			public int insert(Participants participant) throws ClassNotFoundException, SQLException {
				Connection con=DbUtil.getDbConn();
				String sql="insert into participants values(?,?,?,?)";
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setInt(1,participant.getPid());
				ps.setString(2,participant.getPassword());
				ps.setString(3,participant.getPname());
				ps.setString(4,participant.getPemail());
				return ps.executeUpdate();
				
			}
			
			//retrive
		public List<Participants> displayParticipants() throws ClassNotFoundException, SQLException{
			Connection con=DbUtil.getDbConn();
			String sql="select * from participants";
			PreparedStatement ps=con.prepareStatement(sql);
			List<Participants> list=new ArrayList<>();
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				Participants participant=new Participants();
				participant.setPid(rs.getInt("pid"));
				participant.setPname(rs.getString("pname"));
				participant.setPassword(rs.getString("password"));
				participant.setPemail(rs.getString("pemail"));
				list.add(participant);
			}
			return list;
			
		}
			//select by id
		public Participants selectById(int id) throws ClassNotFoundException, SQLException {
			Connection con=DbUtil.getDbConn();
			System.out.println("pid inside selectById"+id);
			String sql="select * from participants where pid=?";
			PreparedStatement ps=con.prepareStatement(sql);
			
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
		if(rs.next()) {
			System.out.println("rs is not empty");
		}
				int pid=rs.getInt("pid");
				String pname=rs.getString("pname");
				String password=rs.getString("password");
				String pemail=rs.getString("pemail");
				Participants participants=new Participants(pid, password, pname, pemail);
				
				return participants;
			
			
		}
		//update 
		public int edit(Participants participants) throws ClassNotFoundException, SQLException {
			Connection con=DbUtil.getDbConn();
			//System.out.println("pid inside edit method in product dao"+product.getPid());
			String sql="update participants set password=?,pname=?,pemail=? where pid=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,participants.getPassword());
			ps.setString(2, participants.getPname());
			ps.setString(3, participants.getPemail());
			ps.setInt(4, participants.getPid());
			return ps.executeUpdate();
		}
			
		//delete

		public int delete(int pid) throws ClassNotFoundException, SQLException {
			Connection con=DbUtil.getDbConn();
			System.out.println("pid inside delete method in product dao"+pid);
			String sql="delete from participants  where pid=?";
			PreparedStatement ps=con.prepareStatement(sql);		
			ps.setInt(1, pid);
			return ps.executeUpdate();
		}
////////user login related 
		
		public String validate(Participants participant) throws ClassNotFoundException, SQLException {
			Connection con=DbUtil.getDbConn();
			String sql="select * from participants where pid=? AND password=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, participant.getPid());
			ps.setString(2,participant.getPassword());
			ResultSet rs=ps.executeQuery();
			
			System.out.println("pid inside user login method"+participant.getPid());
			Participants resParticipant= new Participants();
			
			if(rs.next()) {
				
					
						return rs.getString("pname");
						
					
				}
				
				else {
					System.out.println("not a registered participant");
					return "doReg";
				}
				
			
		}

	}



